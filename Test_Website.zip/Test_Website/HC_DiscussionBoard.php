<?php
session_start();

// Redirect to login page with signal if not logged in
if (!isset($_SESSION["logged_in"]) || $_SESSION["logged_in"] !== true) {
    header("Location: HC_Login.php?auth=required");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="hope_collective_css.css">
	<title>Emerging Hope Therapy and Wellness</title>
</head>
<body>

	<!-- Navigation Bar Menu -->
	<nav class="navbar">
		<div class="navbar-logo">
			<h1>Emerging Hope Therapy and Wellness</h1>
		</div>
		<ul class="navbar-links">
			<?php if (isset($_SESSION["logged_in"]) && $_SESSION["logged_in"] === true): ?>
				<li><a href="HC_Logout.php">Logout (<?php echo htmlspecialchars($_SESSION["username"]); ?>)</a></li>
			<?php else: ?>
				<li><a href="HC_Login.php">Login</a></li>
			<?php endif; ?>

			<li><a href="HC_Home.php">Home</a></li>
			<li><a href="HC_HopeCollective.php">Hope Collective</a></li>
			<li><a href="HC_DiscussionBoard.php" class="active">Discussion Board</a></li>
			<li><a href="HC_Webinar.php">Webinar</a></li>
			<li><a href="HC_Resources.php">Resources</a></li>
		</ul>
	</nav>
	
	<!--Main Body-->
	<main class="main-body">
		<h1>Discussion Board</h1>
		<p>Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?>! You are now viewing the protected Hope Collective Discussion Board.</p>
		<div style="height: 1000px; background: linear-gradient(#e2e2e2, #b5b5b5); padding: 20px; border-radius: 8px;">
			<p><em>This Is The Hope Collective Discussion Board Page!</em></p>
		</div>
	</main>

</body>
</html>
