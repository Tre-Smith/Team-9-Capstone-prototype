<?php
session_start();

// Clear all session variables and destroy the session
session_unset();
session_destroy();

// Redirect back to the login page
header("Location: HC_Login.php");
exit;
?>
