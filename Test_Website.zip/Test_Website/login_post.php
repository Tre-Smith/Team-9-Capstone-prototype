<?php
  //Login Info
 $val_username = "Admin";
 $val_password = hash('sha256',"password123");
  
 $vd_message = "";
 
 //Validation
if (isset($_POST["username"])&& isset($_POST["password"])) {
   $username = htmlspecialchars($_POST["username"]);
   $password = hash('sha256',  $_POST["password"]);
   
   if ($username == $val_username && $password == $val_password){
       $vd_message = "POST Login SuccessFul!";
   } else {
       $vd_message = "POST Login Failed. Invalid username or password,";
   }
}       
?>

<!DOCTYPE html>
<html>
    <head>
        <title>POST Login</title>
    </head>
    <body>
        
        <h2> Login Using Post </h2>
        
        <p><strong><?php echo $vd_message; ?></strong></p>
        
        <form method="POST" action="login_post.php">
            <label>Username:</label>
            <input type="text" name="username" required>
            
            <label>Password:</label>
            <input type="password" name="password" required>
            
            <input type="submit" value="Login with POST">
        </form>
        
    </body>
</html>
