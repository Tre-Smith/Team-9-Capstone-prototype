<?php
session_start();

// If already logged in, skip the login screen
if (isset($_SESSION["logged_in"]) && $_SESSION["logged_in"] === true) {
    header("Location: HC_DiscussionBoard.php");
    exit;
}

// Login Info
$val_username = "Admin";
$val_password = hash('sha256', "password123");
$vd_message = "";

// Validation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["username"], $_POST["password"])) {
    $username = trim($_POST["username"]);
    $password = hash('sha256', $_POST["password"]);

    if ($username === $val_username && $password === $val_password) {
        $_SESSION["logged_in"] = true;
        $_SESSION["username"] = $username;

        
        header("Location: HC_DiscussionBoard.php");
        exit;
    } else {
        $vd_message = "Login Failed. Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="hope_collective_css.css">
	<title>Emerging Hope Therapy</title>
</head>
<body>

	<!-- Navigation Bar Menu -->
	<nav class="navbar">
		<div class="navbar-logo">
			<h1>Emerging Hope Therapy</h1>
		</div>
		<ul class="navbar-links">
			<li><a href="HC_Login.php" class="active">Login</a></li>
			<li><a href="HC_Home.php">Home</a></li>
			<li><a href="HC_HopeCollective.php">Hope Collective</a></li>
			<li><a href="HC_DiscussionBoard.php">Discussion Board</a></li>
			<li><a href="HC_About.php">About</a></li>
			<li><a href="HC_Resources.php">Resources</a></li>
		</ul>
	</nav>
	
	<!--Main Body-->
	<main class="main-body">
		<h1>Login Page</h1>
		<p>Please sign in to access the Hope Collective Discussion Board.</p>

		<div style="background: linear-gradient(#e2e2e2, #b5b5b5); padding: 30px; border-radius: 8px; max-width: 400px; margin-top: 20px;">
			
			<?php if (isset($_GET["auth"]) && $_GET["auth"] === "required"): ?>
				<p style="background-color: #fff3cd; color: #856404; border: 1px solid #ffeeba; padding: 10px; border-radius: 4px; font-weight: bold; margin-bottom: 15px;">
					Please log in to view the Discussion Board.
				</p>
			<?php endif; ?>

			<?php if ($vd_message !== ""): ?>
				<p style="color: #b30000; font-weight: bold; margin-bottom: 15px;">
					<?php echo htmlspecialchars($vd_message); ?>
				</p>
			<?php endif; ?>

			<form method="POST" action="HC_Login.php">
				<div style="margin-bottom: 15px;">
					<label for="username" style="display: block; font-weight: bold; margin-bottom: 5px;">Username:</label>
					<input type="text" id="username" name="username" required style="width: 100%; padding: 8px; box-sizing: border-box;">
				</div>

				<div style="margin-bottom: 20px;">
					<label for="password" style="display: block; font-weight: bold; margin-bottom: 5px;">Password:</label>
					<input type="password" id="password" name="password" required style="width: 100%; padding: 8px; box-sizing: border-box;">
				</div>

				<button type="submit" style="padding: 10px 20px; font-weight: bold; cursor: pointer;">Log In</button>
			</form>

		</div>
	</main>

</body>
</html>
